qemu-system-i386 -serial msmouse -cdrom myos.iso
